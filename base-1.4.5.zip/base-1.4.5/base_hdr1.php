<div class="mainheadertitle">&nbsp;<?php echo _TITLE;
If (@$_COOKIE['archive'] == 1)
    echo('-- ARCHIVE');
?></div>

